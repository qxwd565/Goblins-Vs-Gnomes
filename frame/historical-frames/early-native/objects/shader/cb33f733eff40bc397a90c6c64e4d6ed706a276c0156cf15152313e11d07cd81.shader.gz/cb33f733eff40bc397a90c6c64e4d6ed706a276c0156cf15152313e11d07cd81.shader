Shader "Custom/Selection/Highlight" {
Properties {
 _Color ("Base Color", Color) = (0.5,0.5,0.5,1)
 _HiColor ("Hot Color", Color) = (0.5,0.5,0.5,1)
 _Colorize ("Colorize", Color) = (1,1,1,1)
 _ColorIntensity ("Color Intensity", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _MoteTex ("Mote Texture", 2D) = "white" {}
 _MoteIntensity ("Mote Intensity", Float) = 1
 _VmoteSpeed ("Mote V Speed", Float) = 1
 _UmoteScale ("Mote U Scale", Float) = 1
 _VmoteScale ("Mote V Scale", Float) = 1
 _FlareTex ("Flare Texture", 2D) = "white" {}
 _FlareIntensity ("Flare Intensity", Float) = 1
 _VflareSpeed ("Flare V Speed", Float) = 1
 _UflareScale ("Flare U Scale", Float) = 1
 _VflareScale ("Flare V Scale", Float) = 1
 _MainTex ("Main Texture", 2D) = "black" {}
 _Seed ("Seed", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend SrcAlpha OneMinusSrcAlpha
  ColorMask RGB
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesMultiTexCoord1;
uniform highp mat4 glstate_matrix_mvp;
uniform mediump float _Seed;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  highp vec2 tmpvar_1;
  tmpvar_1.x = (_glesMultiTexCoord1.x + _Seed);
  tmpvar_1.y = _glesMultiTexCoord1.y;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((tmpvar_1 * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_COLOR = _glesColor;
}



#endif
#ifdef FRAGMENT

uniform highp vec4 _Time;
uniform sampler2D _MainTex;
uniform sampler2D _MoteTex;
uniform sampler2D _FlareTex;
uniform lowp vec4 _Color;
uniform lowp vec4 _Colorize;
uniform mediump vec4 _HiColor;
uniform mediump float _ColorIntensity;
uniform mediump float _Intensity;
uniform mediump float _FlareIntensity;
uniform mediump float _MoteIntensity;
uniform mediump float _VmoteSpeed;
uniform mediump float _UmoteScale;
uniform mediump float _VmoteScale;
uniform mediump float _VflareSpeed;
uniform mediump float _UflareScale;
uniform mediump float _VflareScale;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 mote_3;
  mediump float flare_4;
  highp float v_5;
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture2D (_MainTex, xlv_TEXCOORD0);
  mediump float tmpvar_7;
  tmpvar_7 = (tmpvar_6.x * _Intensity);
  v_5 = tmpvar_7;
  highp vec2 tmpvar_8;
  tmpvar_8.x = ((xlv_TEXCOORD1.x * _UflareScale) + fract((_Time.x * 0.05)));
  tmpvar_8.y = ((v_5 * _VflareScale) + fract((_Time.x * _VflareSpeed)));
  highp vec2 tmpvar_9;
  tmpvar_9.x = (xlv_TEXCOORD1.x * _UmoteScale);
  tmpvar_9.y = ((v_5 * _VmoteScale) + fract((_Time.x * _VmoteSpeed)));
  lowp vec4 tmpvar_10;
  tmpvar_10 = texture2D (_FlareTex, tmpvar_8);
  highp float tmpvar_11;
  tmpvar_11 = ((tmpvar_10.x * _FlareIntensity) * v_5);
  flare_4 = tmpvar_11;
  lowp vec4 tmpvar_12;
  tmpvar_12 = texture2D (_MoteTex, tmpvar_9);
  highp vec4 tmpvar_13;
  tmpvar_13 = ((((clamp ((((tmpvar_12 * xlv_COLOR.x) * 0.5) + v_5), 0.0, 1.0) + flare_4) * _MoteIntensity) * v_5) * xlv_COLOR.x);
  mote_3 = tmpvar_13;
  col_2.xyz = (mix (_Color, ((_HiColor * mote_3) + flare_4), mote_3) * _ColorIntensity).xyz;
  col_2.w = mote_3.x;
  tmpvar_1 = (col_2 * _Colorize);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX

in vec4 _glesVertex;
in vec4 _glesColor;
in vec4 _glesMultiTexCoord0;
in vec4 _glesMultiTexCoord1;
uniform highp mat4 glstate_matrix_mvp;
uniform mediump float _Seed;
uniform highp vec4 _MainTex_ST;
out highp vec2 xlv_TEXCOORD0;
out highp vec2 xlv_TEXCOORD1;
out lowp vec4 xlv_COLOR;
void main ()
{
  highp vec2 tmpvar_1;
  tmpvar_1.x = (_glesMultiTexCoord1.x + _Seed);
  tmpvar_1.y = _glesMultiTexCoord1.y;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((tmpvar_1 * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_COLOR = _glesColor;
}



#endif
#ifdef FRAGMENT

out mediump vec4 _glesFragData[4];
uniform highp vec4 _Time;
uniform sampler2D _MainTex;
uniform sampler2D _MoteTex;
uniform sampler2D _FlareTex;
uniform lowp vec4 _Color;
uniform lowp vec4 _Colorize;
uniform mediump vec4 _HiColor;
uniform mediump float _ColorIntensity;
uniform mediump float _Intensity;
uniform mediump float _FlareIntensity;
uniform mediump float _MoteIntensity;
uniform mediump float _VmoteSpeed;
uniform mediump float _UmoteScale;
uniform mediump float _VmoteScale;
uniform mediump float _VflareSpeed;
uniform mediump float _UflareScale;
uniform mediump float _VflareScale;
in highp vec2 xlv_TEXCOORD0;
in highp vec2 xlv_TEXCOORD1;
in lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 mote_3;
  mediump float flare_4;
  highp float v_5;
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture (_MainTex, xlv_TEXCOORD0);
  mediump float tmpvar_7;
  tmpvar_7 = (tmpvar_6.x * _Intensity);
  v_5 = tmpvar_7;
  highp vec2 tmpvar_8;
  tmpvar_8.x = ((xlv_TEXCOORD1.x * _UflareScale) + fract((_Time.x * 0.05)));
  tmpvar_8.y = ((v_5 * _VflareScale) + fract((_Time.x * _VflareSpeed)));
  highp vec2 tmpvar_9;
  tmpvar_9.x = (xlv_TEXCOORD1.x * _UmoteScale);
  tmpvar_9.y = ((v_5 * _VmoteScale) + fract((_Time.x * _VmoteSpeed)));
  lowp vec4 tmpvar_10;
  tmpvar_10 = texture (_FlareTex, tmpvar_8);
  highp float tmpvar_11;
  tmpvar_11 = ((tmpvar_10.x * _FlareIntensity) * v_5);
  flare_4 = tmpvar_11;
  lowp vec4 tmpvar_12;
  tmpvar_12 = texture (_MoteTex, tmpvar_9);
  highp vec4 tmpvar_13;
  tmpvar_13 = ((((clamp ((((tmpvar_12 * xlv_COLOR.x) * 0.5) + v_5), 0.0, 1.0) + flare_4) * _MoteIntensity) * v_5) * xlv_COLOR.x);
  mote_3 = tmpvar_13;
  col_2.xyz = (mix (_Color, ((_HiColor * mote_3) + flare_4), mote_3) * _ColorIntensity).xyz;
  col_2.w = mote_3.x;
  tmpvar_1 = (col_2 * _Colorize);
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
}
 }
}
Fallback Off
}