Shader "Effects/FX_Desaturate" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _Color ("Light Color", Color) = (0.6,0.6,0.6,1)
 _DarkColor ("Dark Color", Color) = (0.3,0.3,0.3,1)
 _Desaturate ("Desaturate", Float) = 1
 _Contrast ("Contrast", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _AvgLum ("Average Luminosity", Color) = (0.5,0.5,0.5,1)
}
SubShader { 
 Tags { "RenderType"="Opaque" }
 Pass {
  Tags { "RenderType"="Opaque" }
  BindChannels {
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesMultiTexCoord0;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
void main ()
{
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
uniform lowp vec4 _DarkColor;
uniform mediump float _Desaturate;
uniform highp float _Contrast;
uniform highp float _Intensity;
uniform lowp vec4 _AvgLum;
varying highp vec2 xlv_TEXCOORD0;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture2D (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  mediump vec4 tmpvar_4;
  tmpvar_4 = mix (col_2, mix (_DarkColor, _Color, vec4(dot (vec3(0.3, 0.59, 0.11), col_2.xyz))), vec4(_Desaturate));
  highp vec4 tmpvar_5;
  tmpvar_5 = mix (tmpvar_4, _AvgLum, vec4(_Contrast));
  col_2 = tmpvar_5;
  tmpvar_1 = (col_2 * _Intensity);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX

in vec4 _glesVertex;
in vec4 _glesMultiTexCoord0;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 _MainTex_ST;
out highp vec2 xlv_TEXCOORD0;
void main ()
{
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
}



#endif
#ifdef FRAGMENT

out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
uniform lowp vec4 _DarkColor;
uniform mediump float _Desaturate;
uniform highp float _Contrast;
uniform highp float _Intensity;
uniform lowp vec4 _AvgLum;
in highp vec2 xlv_TEXCOORD0;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  mediump vec4 tmpvar_4;
  tmpvar_4 = mix (col_2, mix (_DarkColor, _Color, vec4(dot (vec3(0.3, 0.59, 0.11), col_2.xyz))), vec4(_Desaturate));
  highp vec4 tmpvar_5;
  tmpvar_5 = mix (tmpvar_4, _AvgLum, vec4(_Contrast));
  col_2 = tmpvar_5;
  tmpvar_1 = (col_2 * _Intensity);
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
}
 }
}
Fallback Off
}