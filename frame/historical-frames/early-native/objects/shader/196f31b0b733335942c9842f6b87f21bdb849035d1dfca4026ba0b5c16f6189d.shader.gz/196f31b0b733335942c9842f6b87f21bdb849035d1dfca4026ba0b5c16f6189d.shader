Shader "Hero/AddMultiplyFXScrolling" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "white" {}
 _Intensity ("Intensity", Float) = 1
 _FxTex ("FX Texture", 2D) = "white" {}
 _FxIntensity ("FX Intensity", Float) = 1
 _ScrollX ("FX Scroll X", Float) = 0
 _ScrollY ("FX Scroll Y", Float) = 0
 _ScaleX ("FX Scale X", Float) = 1
 _ScaleY ("FX Scale Y", Float) = 1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend One OneMinusSrcAlpha
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _Color;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec2 tmpvar_2;
  tmpvar_2 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_2.x * _ScaleX) + (_Time.x * _ScrollX));
  tmpvar_3.y = ((tmpvar_2.y * _ScaleY) + (_Time.x * _ScrollY));
  highp vec4 tmpvar_4;
  tmpvar_4 = (mix (_glesColor, (((glstate_lightmodel_ambient * 2.0) + _LightColor0) * _glesColor), vec4(_LightingBlend)) * _Color.w);
  tmpvar_1 = tmpvar_4;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_2;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform highp float _FxIntensity;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 fx_3;
  mediump vec4 tex_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_MainTex, xlv_TEXCOORD0);
  tex_4 = tmpvar_5;
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture2D (_FxTex, xlv_TEXCOORD1);
  highp vec4 tmpvar_7;
  tmpvar_7 = (tmpvar_6 * _FxIntensity);
  fx_3 = tmpvar_7;
  col_2.xyz = (_Color.xyz * tex_4.xyz);
  col_2.w = (tex_4.w * (_Color.w - tex_4.w));
  tmpvar_1 = (((2.0 * (col_2 * fx_3)) * _Intensity) * xlv_COLOR);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX

in vec4 _glesVertex;
in vec4 _glesColor;
in vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _Color;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
out highp vec2 xlv_TEXCOORD0;
out highp vec2 xlv_TEXCOORD1;
out lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec2 tmpvar_2;
  tmpvar_2 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_2.x * _ScaleX) + (_Time.x * _ScrollX));
  tmpvar_3.y = ((tmpvar_2.y * _ScaleY) + (_Time.x * _ScrollY));
  highp vec4 tmpvar_4;
  tmpvar_4 = (mix (_glesColor, (((glstate_lightmodel_ambient * 2.0) + _LightColor0) * _glesColor), vec4(_LightingBlend)) * _Color.w);
  tmpvar_1 = tmpvar_4;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_2;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT

out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform highp float _FxIntensity;
in highp vec2 xlv_TEXCOORD0;
in highp vec2 xlv_TEXCOORD1;
in lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 fx_3;
  mediump vec4 tex_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture (_MainTex, xlv_TEXCOORD0);
  tex_4 = tmpvar_5;
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture (_FxTex, xlv_TEXCOORD1);
  highp vec4 tmpvar_7;
  tmpvar_7 = (tmpvar_6 * _FxIntensity);
  fx_3 = tmpvar_7;
  col_2.xyz = (_Color.xyz * tex_4.xyz);
  col_2.w = (tex_4.w * (_Color.w - tex_4.w));
  tmpvar_1 = (((2.0 * (col_2 * fx_3)) * _Intensity) * xlv_COLOR);
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
}
 }
}
Fallback Off
}