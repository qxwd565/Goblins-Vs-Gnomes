Shader "Custom/FX_GhostCard" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "black" {}
 _TexIntensity ("Main Texture Intensity", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _FxTex ("FX Texture", 2D) = "black" {}
 _FxIntensity ("FX Intensity", Float) = 1
 _FxDistortion ("FX Distortion", Float) = 1
 _ScrollX ("FX Scroll X", Float) = 0
 _ScrollY ("FX Scroll Y", Float) = 0
 _ScaleX ("FX Scale X", Float) = 1
 _ScaleY ("FX Scale Y", Float) = 1
 _Seed ("Seed", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend One OneMinusSrcAlpha
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _Seed;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  highp vec2 tmpvar_1;
  tmpvar_1 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp float tmpvar_2;
  tmpvar_2 = (_Time.x + _Seed);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_1.x * _ScaleX) + (tmpvar_2 * _ScrollX));
  tmpvar_3.y = ((tmpvar_1.y * _ScaleY) + (tmpvar_2 * _ScrollY));
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_1;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = _glesColor;
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform mediump float _TexIntensity;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform mediump float _FxIntensity;
uniform mediump float _FxDistortion;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture2D (_FxTex, xlv_TEXCOORD1);
  mediump float tmpvar_4;
  tmpvar_4 = (tmpvar_3 * _FxIntensity).x;
  highp vec2 tmpvar_5;
  tmpvar_5.x = (xlv_TEXCOORD0.x + ((tmpvar_4 * 0.01) * _FxDistortion));
  tmpvar_5.y = (xlv_TEXCOORD0.y + ((tmpvar_4 * 0.005) * _FxDistortion));
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture2D (_MainTex, tmpvar_5);
  mediump vec4 tmpvar_7;
  tmpvar_7 = (tmpvar_6 * _TexIntensity);
  col_2.xyz = ((_Color.xyz * vec3(tmpvar_4)) * 2.0);
  col_2.w = tmpvar_4;
  highp vec4 tmpvar_8;
  tmpvar_8 = ((((((2.0 * (col_2 * vec4(tmpvar_4))) * _Intensity) * xlv_COLOR) + tmpvar_7) * tmpvar_7.w) * _Color.w);
  col_2 = tmpvar_8;
  mediump float tmpvar_9;
  tmpvar_9 = dot (vec3(0.3, 0.59, 0.11), col_2.xyz);
  mediump vec4 tmpvar_10;
  tmpvar_10.x = tmpvar_9;
  tmpvar_10.y = tmpvar_9;
  tmpvar_10.z = tmpvar_9;
  tmpvar_10.w = col_2.w;
  mediump vec4 tmpvar_11;
  tmpvar_11 = (mix (col_2, tmpvar_10, vec4(0.7, 0.7, 0.7, 0.7)) * vec4(1.2, 1.2, 1.7, 1.4));
  col_2 = tmpvar_11;
  mediump vec4 tmpvar_12;
  tmpvar_12 = clamp (tmpvar_11, 0.0, 1.0);
  tmpvar_1 = tmpvar_12;
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX

in vec4 _glesVertex;
in vec4 _glesColor;
in vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _Seed;
uniform highp vec4 _MainTex_ST;
out highp vec2 xlv_TEXCOORD0;
out highp vec2 xlv_TEXCOORD1;
out lowp vec4 xlv_COLOR;
void main ()
{
  highp vec2 tmpvar_1;
  tmpvar_1 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp float tmpvar_2;
  tmpvar_2 = (_Time.x + _Seed);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_1.x * _ScaleX) + (tmpvar_2 * _ScrollX));
  tmpvar_3.y = ((tmpvar_1.y * _ScaleY) + (tmpvar_2 * _ScrollY));
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_1;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = _glesColor;
}



#endif
#ifdef FRAGMENT

out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform mediump float _TexIntensity;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform mediump float _FxIntensity;
uniform mediump float _FxDistortion;
in highp vec2 xlv_TEXCOORD0;
in highp vec2 xlv_TEXCOORD1;
in lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture (_FxTex, xlv_TEXCOORD1);
  mediump float tmpvar_4;
  tmpvar_4 = (tmpvar_3 * _FxIntensity).x;
  highp vec2 tmpvar_5;
  tmpvar_5.x = (xlv_TEXCOORD0.x + ((tmpvar_4 * 0.01) * _FxDistortion));
  tmpvar_5.y = (xlv_TEXCOORD0.y + ((tmpvar_4 * 0.005) * _FxDistortion));
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture (_MainTex, tmpvar_5);
  mediump vec4 tmpvar_7;
  tmpvar_7 = (tmpvar_6 * _TexIntensity);
  col_2.xyz = ((_Color.xyz * vec3(tmpvar_4)) * 2.0);
  col_2.w = tmpvar_4;
  highp vec4 tmpvar_8;
  tmpvar_8 = ((((((2.0 * (col_2 * vec4(tmpvar_4))) * _Intensity) * xlv_COLOR) + tmpvar_7) * tmpvar_7.w) * _Color.w);
  col_2 = tmpvar_8;
  mediump float tmpvar_9;
  tmpvar_9 = dot (vec3(0.3, 0.59, 0.11), col_2.xyz);
  mediump vec4 tmpvar_10;
  tmpvar_10.x = tmpvar_9;
  tmpvar_10.y = tmpvar_9;
  tmpvar_10.z = tmpvar_9;
  tmpvar_10.w = col_2.w;
  mediump vec4 tmpvar_11;
  tmpvar_11 = (mix (col_2, tmpvar_10, vec4(0.7, 0.7, 0.7, 0.7)) * vec4(1.2, 1.2, 1.7, 1.4));
  col_2 = tmpvar_11;
  mediump vec4 tmpvar_12;
  tmpvar_12 = clamp (tmpvar_11, 0.0, 1.0);
  tmpvar_1 = tmpvar_12;
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
}
 }
}
Fallback Off
}